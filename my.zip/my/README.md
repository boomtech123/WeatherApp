# How to use the project

- Clone
- Install dependencies (npm i)
- Get your API key and add to weatherService.js
- Enjoy!!

> Leave a star :)
