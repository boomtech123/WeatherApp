import React from 'react';
import SearchCities from './SearchCities';

function App() {
  return (
    <div className= "App">
      <div>
      <br>
      </br>
      <br>
      </br>
      <h1>Know Air Quality Index(AQI)</h1>
      <SearchCities />
    </div>
    </div>
  );
}

export default App;
