
export const TOKEN = '2d71850fc24edb7443b5922b70f3587eabb14119';
export const SEARCH_CITIES_BASE_URL = 'https://api.waqi.info/search/';
export const FEED_AQI_BASE_URL = 'https://api.waqi.info/feed/@';